public interface Annuaire extends java.rmi.Remote {
    String chercheNom(String nom) throws java.rmi.RemoteException;
}
