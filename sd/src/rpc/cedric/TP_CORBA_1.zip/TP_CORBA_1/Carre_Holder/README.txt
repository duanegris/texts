Avant d'exécuter la commande "make", il faut déclarer le nom de l'interface par

export INTERFACE=<nom interface>

Exemple :

export INTERFACE=Icarre


