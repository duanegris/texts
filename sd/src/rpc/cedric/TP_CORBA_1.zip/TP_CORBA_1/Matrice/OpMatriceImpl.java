
public class OpMatriceImpl 
    extends _OpMatriceImplBase {
    
    public ??? addMat(???) { 
    ???  res = new ????;
    for (int i = 0; i < a.length; ++i) 
        for (int j = 0; j < b[0].length; ++j) 
               res[i][j] = a[i][j] + b[i][j];
    return(res);
    }

}
