#include "include.h"

entiers2 * divise(entiers2 *e) { 
  ????
}
int main (void) {
  bool_t stat;
  registerrpc(????);
  
  svc_run(); /* le serveur est en attente de clients eventuels */
  return(0); /* on y passe jamais ! */
}


