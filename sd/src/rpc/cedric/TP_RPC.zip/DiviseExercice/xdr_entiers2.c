#include "include.h"
bool_t xdr_entiers2(XDR *xdrs, entiers2 *e) {
  ????
}
