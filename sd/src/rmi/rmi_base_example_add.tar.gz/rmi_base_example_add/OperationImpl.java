import java.rmi.server.UnicastRemoteObject ;
import java.rmi.RemoteException ;
import java.net.InetAddress.* ;
import java.net.* ;

public class OperationImpl 
    extends UnicastRemoteObject
    implements Operation  {

    public OperationImpl () throws RemoteException 
    { 
      super(); 
    };

    public int addition(int a, int b) throws RemoteException { 
	return( a + b) ;
    }
}
