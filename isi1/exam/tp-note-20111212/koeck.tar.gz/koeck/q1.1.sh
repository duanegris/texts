#!/bin/sh

cut -d' ' -f 1-2 ventes.dat