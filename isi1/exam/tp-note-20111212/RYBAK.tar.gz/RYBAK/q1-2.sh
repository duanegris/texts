echo "Saisie d'une nouvelle ligne : "
read var
echo $var >> "ventes.dat"
