#!/bin/bash

file=$1
data=$2

grep ^[a-z] 
read data

