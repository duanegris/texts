#! /bin/bash

if [ $# != 2 ]
then
	echo "usage     : ./q2.1.sh <operation> <valeur>"
	echo "operation : 'sel c'"
	echo "valeur    : 'som m'"
	exit 1
else
	echo "tout va bien, arguments conformes"
fi
