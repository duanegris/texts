#! /bin/bash

read a

echo $a >> ventes.dat
