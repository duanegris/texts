
phrase=""
echo "entrer la phrase"
read phrase

echo "$phrase"
