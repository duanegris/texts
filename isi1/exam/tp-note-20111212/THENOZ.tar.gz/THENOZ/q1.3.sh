


a=echo `date|cut -d,`
echo "$a"



[ -f $a ]  #test si c'est un fichier
b=
mkdir <n>-a
cp <n>.date <n>-a
