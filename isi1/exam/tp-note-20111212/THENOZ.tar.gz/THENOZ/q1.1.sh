
tableau=echo `cat ventes.dat|cut -f 1-7`
echo "$tableau"
