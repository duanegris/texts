read -p 'Entrer une ligne de données : ' donnee
