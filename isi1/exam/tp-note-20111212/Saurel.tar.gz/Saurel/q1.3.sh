data=`find *.dat`
mkdir "$data-`date`"
