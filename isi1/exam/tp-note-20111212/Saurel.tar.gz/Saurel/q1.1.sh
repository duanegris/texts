cut -c -7 ventes.dat

# utiliser sort pour le classement
