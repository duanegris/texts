# !/bin/sh
file=/home/tian/Bureau/TIAN/ventes.dat
echo " `chmod a+x ventes.dat` "
ajouter="mars 20 10 20 30 15"
echo " `$(($file + $ajouter))` "

