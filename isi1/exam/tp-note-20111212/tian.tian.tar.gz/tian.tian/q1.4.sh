# !/bin/sh

file1="ventes.dat"
n=`$file2 | wc-l`
file2="$n.dat"
echo " `chmod a+x "$n.dat" ` "
echo " `cp file2 file1` "
