# !/bin/sh
fonction sel()
read n
file=`$file| cut -f$n -d' '`

