# !/bin/sh

if [ $1==(sel||som) -a $2>=0 ]
then (echo "vrai"
	exit 1;)
else echo "erreur"
	exit $s;
else echo "usage sel ou som + int"
	
fi
	
