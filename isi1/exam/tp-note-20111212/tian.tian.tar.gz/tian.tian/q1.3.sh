# !/bin/sh

filename="`ls`"
if [ filename=$n.dat ] then
	echo "$n"
	repertoire="$n-`date`"
echo " `cp $repertoire  $n` "
	
fi
