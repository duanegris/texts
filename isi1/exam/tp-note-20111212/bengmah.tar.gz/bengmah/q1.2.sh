file=vente.dat

read -p "Entrez une nouvelle ligne " line

echo $line >> $file
