#!/bin/sh

read  ligne
echo $ligne >> ventes.dat
