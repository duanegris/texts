#!/bin/sh

cut -d" " -f1,2 ventes.dat | sort -k 2
