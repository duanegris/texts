#!/bin/sh

bin=$1

while (( bin > 0 ))

do
 
   echo 
