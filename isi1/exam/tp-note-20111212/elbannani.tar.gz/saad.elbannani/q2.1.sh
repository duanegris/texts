#!/bin/sh

nbarg=$*

if [ $nbarg != 2 ]
then 
echo "usage : ./<nom_programme> <operation> <valeur> "
exit 1
fi
