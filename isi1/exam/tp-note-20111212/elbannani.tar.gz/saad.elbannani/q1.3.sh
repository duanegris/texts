#!/bin/sh




find  *.dat | cut -f1 -d. > mkdir




