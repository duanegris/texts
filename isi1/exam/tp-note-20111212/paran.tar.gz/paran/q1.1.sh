#!/bin/bash

cat ventes.dat | cut -c 1-4,5-7


