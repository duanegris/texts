echo "Ecrire une nouvelle ligne de donnée :"
read res
$res >> ventes.sh	#rajoutera à la fin et ne supprimera pas ventes.dat
